import React,{useRef, useState, useMemo} from "react";
//react에서 use hook를 불러옴
// const 변수 = useMemo(()=>{
//     return 계산하는 무거운 함수()
// }, [감시하고 있는 함수])
// state가 있는 컴포넌트에 state 변화가 생기면 재평가 후 
// 새로 랜더링 하기 떄문
function App (){
    //inputName 과 Id, useRef 사용해 각각의 인풋 요소에 대한 참조 생성
    const inputName = useRef(null);
    const inputId = useRef(null);

    const [userInfo, setUserInfo ] = useState([])
    //useinfo에 ㅎ상태와 그에 대한 업데이트 함수와 초기값인 배열 생설
    const[name, setName] = useState("")
    const[id, setId] = useState("")

    function handleName(e){
        setName(e.target.value)
        console.log('rendering -1')
    }
    function handleId(e){
        setId(e.target.value)
        console.log('rendering -2')
    }
    function handleSubmit(e){
        e.preventDefault()
        const newInfo = [...userInfo, {name,id}]
        inputName.current.value = ''
        inputId.current.value = ''
        inputName.current.focus()
        setUserInfo(newInfo)
        console.log('rendering -3')
        
    }
    function getNum(user){
        console.log('getNum rendering')
        return user.length
    }
    //userInfo 배열이 변경될떄마다 getNum 함수를 호출해 결과를 n에 저장
    const n = useMemo(() =>getNum(userInfo),[userInfo])
    //컴포넌트의 반환 부분에서 입력란 버튼 목록 n 변수값 표시
    return(
        <div className="App">
            <form>
                <input
                type="text"
                placeholder="이름 입력하세요"
                onChange={handleName}
                ref={inputName}>
                </input>

                <input
                type="text"
                placeholder="아이디 입력세요"
                onChange={handleId}
                ref={inputId}>
                </input>

                <button
                type="submit"
                onClick={handleSubmit}
                >submit 
                </button>
            </form>
            <ul>
                {userInfo.map((value, index)=>(
                    <li key={index}>
                        <h3>{value.name}</h3>
                        <strong>@{value.id}</strong>
                    </li>
                ))}
            </ul>
            <span>{n}</span>
        </div>
    )
}
export default App;
// 이름을 입력할때  setName
// 아이디 입력 setId
// 버튼  setUserInfo + getnum