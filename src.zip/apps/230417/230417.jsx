import React,{useRef, useState} from "react";
//useRef 를 사용해 dom 요소에 대한 참조를 저장하고
// 해당요소의 값을 갖와 상태를 
// 자바스크립트로 치면 getElementById 이런 형식을 리엑트에서는 이런 형식을 쓴다

const App = () =>{
    const email = useRef(null)  //email에 대한 useRef
    const pw = useRef(null)     //pw에 대한 useRef

    const[emailValue, setEmailValue] = useState("")
    const[pwValue, setPwValue] = useState("")

    const check = (e) =>{
        e.preventDefault();
        console.log(email)
        console.log(pw)
        setEmailValue(email.current.value);
        setPwValue(pw.current.value);
    }
    return(
        <form style={{display:"flex",flexDirection:"column"}}>
            <label>이메일 : <input type="email" ref={email}></input></label>
            <label>비밀번호: <input type="password" ref={{pw}}></input></label>
            <button type="submit" style={{width:"100px"}}onClick={check}>
                회원가입
            </button>
            <span>{emailValue}</span>
            <span>{pwValue}</span>
        </form>
    )
}
export default App;