import React, {Fragment}  from "react";
function App(){
    
        const productList = {
            product : [{
                title:"담요",
                price:17000,
                id:101
                },

                {
                title:"파우치",
                price:30000,
                id:102 
                },

                {
                title:"컴퓨터",
                price:2000000,
                id:103
                },

                {
                title:"커피",
                price:3000,
                id:104
                }
            ]
        }
    return( //props를 사용하지 않고 컴포넌트 내부에서 변수 만듬
        <div>
            {productList.product.map((el,index)=>{
                return(
                    <div key={el.id}>
                        <h2>{el.title}</h2>
                        <p>{el.price}</p>
                    </div>
                )
            })}
        </div>
    )
}
export default App;
