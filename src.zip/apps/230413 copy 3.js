import { setSelectionRange } from '@testing-library/user-event/dist/utils';
import React from 'react';
import { useState } from 'react';
// import '../css/App.css';

function Resume(props){
  
  const myColor = props.color;
  const styleColor = {color:myColor};
  
  return(
  <div style={{border:"solid 1px", width:"500px"}}>
      <h1>{props.name}자기소개서</h1>
      <h1>{props.hello}</h1>
      <h2>취미 : {props.hobby}</h2>
      <h2>음식 : {props.food}</h2>
      <h2>색 : <span style={styleColor}>{myColor}</span></h2>
      <button onClick={()=>clickLike(props.like, props.setLike)}>like<span>{props.like}</span></button>
    </div>
  )
}
function clickLike(like, setLike){
    setLike(like +1 )
  }
function App(){
  const[like, setLike] = useState(0)
  return(
  <Resume name="홍길동"like = {like}setLike={setLike}/>)
} 

export default App;
//
