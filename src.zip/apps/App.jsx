// import '../css/App.css';
import style from '../app.module.css'
import Test from '../Components/Test'

function App(){
    return(
        <div className='App'>
            <div className={style.test}>test1</div>
            <Test/>
        </div>
    )
}
export default App;



