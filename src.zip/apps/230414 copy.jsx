import React, {Fragment}  from "react";
function App(){
    return(
        <div>
            {[1,2,3].map((number, index)=>{ //number는 속성, index는 속성값
                return<div key={index}>{number}</div>
            })}
            {[1,3,2].map((number, index)=>{
                return<div key={index}>{number}</div>
            })}
        </div>
    )
}
// const num = [ {
// 1:0,o
// 2:1,
// 3:2
// }]
export default App;

