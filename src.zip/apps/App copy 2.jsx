import styled from "styled-components";
import {BrowserRouter, Routes, Route, Link, useLocation, Outlet} from 'react-router-dom';

//라우트는 프론트엔드에서 사용되는 용어로 사용자가
//웹 페이지에서 요청한 url에 따라 적절한 컴포넌트를 
//렌더링하는것 말함

function App(){
    return(
        <BrowserRouter>
        <Link to ='/'>home</Link>
        <Link to ='/one'>one</Link>
        <Link to ='/two'>two</Link>
        <Link to ='/three'>three</Link>
        {/* route를 감싸준다 */}
        <Routes>
            <Route path='/' element={<Index/>}></Route>
            <Route path='/one' element={<One name='licat'/>}></Route>
            <Route path='/two' element={<Two/>}></Route>
            <Route path='/three/*' element={<Outlet/>}>
                <Route path='' element={<ThreeIndex/>}></Route>
                <Route path='hojunone' element={<ThreeOne/>}></Route>
                <Route path='hojuntwo' element={<ThreeTwo/>}></Route>
                    </Route>
                <Route path='/blog/:id' element={<Blog></Blog>}></Route>
                {/* /blog/123의 경우 :id는 123이 되고
                :id 값을 사용해 블로그 게시물의 내용을 렌더링할 수 있다*/}
        </Routes>
        </BrowserRouter>
    )
}
function Index (){
    return<h1>hello world0</h1>
}
function One({name}){
    return<h1>{name} hello world1</h1>
}
function Two(){
    return<h1>hello world2</h1>
}
function Three(){
    return<h1>hello world3</h1>
}
function Blog(){
    const location = useLocation()
    console.log(location)
    return <h1>hello blog</h1>
}
function ThreeIndex(){
    return<h1>hello ThreeIndex</h1>
}
function ThreeOne(){
    return<h1>hello ThreeOne</h1>
}
function ThreeTwo(){
    return<h1>hello ThreeTwo</h1>
}


export default App;
