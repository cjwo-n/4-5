import { setSelectionRange } from '@testing-library/user-event/dist/utils';
import React from 'react';
import { useState } from 'react';
// import '../css/App.css';

function App() {

    let [글제목, 글제목변경] = useState([
      '코트맛집',
      '역전우동',
      '파이썬'
    ]);
    //useState hook 을 사용해 글제목이라는 상태 변수와 글제목변경이라는 상태
    //상태 변경함수 선어 후 초기값으로 문자열 배열 설정
    let [따봉 ,따봉변경]=useState(0);
    //useState 훅을 이용해 따봉 상태와 그를 업데이트할 따봉변경 한수 선언 초기값0
    let [modal, setModal]=useState(false);// 
    //모달도 위와 동일
    let [toggle, setToggle]=useState([false, false, false]);
    //기본닷이 false 3개 배열을 갖는다
  const toggleTitle = (idx)=>{  //함수는 idx(인덱스)를 받ㅇ ㅏ
  const newTitle = [...글제목];
  const newToggle = [...toggle];
    newToggle[idx] = !newToggle[idx];
    //토글에 값을 토글하고 그에 따라 newTitle 배별에 업데이트
    if(idx ===0){
      newTitle[0] = newToggle[idx]? ' 여자코트 추천': '남자코트 추천';
    }else if(idx ===1){
      newTitle[1] = newToggle[idx]? ' 역전우동?': '아님 다른 우동?';
    }else if(idx === 2){
      newTitle[2] = newToggle[idx]? ' 자바독학': ' 파이썬';
    }
    //글제목변경과toggle 함수를 이용해 상태를 업데이트
    글제목변경(newTitle);
    setToggle(newToggle);
  } ;
  //toggleModal 함수는 modal 상태 값을 토글하는 setModal함수
  const toggleModal = ()=>{
    setModal(!modal);
  }
  return(
  <div className='App'>
      <div className='black-nav'>
        <div>개발 블로그</div>
        <hr/>
      </div>
      <div className='list'>
        <h4>
        <button onClick={()=>toggleTitle(0)}>수정버튼1</button>   
        {/*()=> toggleTitle(0) 0은 toggleTitle에 인덱스 값이 0일때의 function을 해당 코드 onClick 기능에 부여
        위에서 index 값을 확인 삼항연산자 부분 */}
          <br/>
          <br/>
          {글제목[0]}<span onClick={()=>따봉변경(따봉 + 1)}>^^</span> 
          {/* 글제목 index [0] 최상단 useState 코트 일떄 구문 클릭시 event 생성 따봉변경 진행  */}
          {따봉}
        </h4>
        <p>4월 13일</p>
        <hr/>
      </div>

      <div className='list'>
      <button onClick={()=>toggleTitle(1)}>수정버튼2</button>
        <h4>{글제목[1]}</h4>
        <p>4월 13일</p>
        <hr></hr>
      </div>

      <div className='list'>
      <button onClick={()=>toggleTitle(2)}>수정버튼3</button>
        <h4 onClick={toggleModal}>{글제목[2]}</h4>
        <p>4월 13일</p>
      </div>
      <hr></hr>
      {modal && <Modal onClose={toggleModal}/>}
    </div>
  );
}
function Modal({onClose}){
  return(
    <div className='modal'>
      <h4>제목</h4>
      <p>날짜</p>
      <p>상세내용</p>
      <button onClick={onClose}>닫기</button>
    </div>
  );
}

export default App;
// 싱글페이지 어플리케이션을 만들떄 사용
// html 재사용 편리
// 같은문법으로 앱개발 가능
// 나중에redux쓰는 이유
// props문법 귀찮을떄 사용
// state 변경관리할때 사용 
//components들을 수정요청만이 가능
//Store.js를 만들어 관리
//복습 jsx문법 
// 1. html에 class 넣을때 className 

// 2. 변수를 html에 꽂아 넣을떄는 {중괄호}
// 자바스크립트 변수 같은 곳에 있던 자료를 html 중간에 꽂아서 보여주고 싶을떄가 많음
// document.getElementById().innerHTML = ?? 과 비슷

// 3. html style 속성 넣고 싶으면 
// <div style = "color:blue"/> 이 형태를
// jsx 상에서 style={"color:blue"} 넣으면 됨

// import {useState} from react 중괄호의 이유
// useState 함수는 배열을 반환하므로 배열 비구조화 할당을 사용해
// 해당 배열의 첫번째 요소를 count 변수 할당 두번째 요소를 setCount에 할당

// const [count, setCount] =useState(0) 코드에서 useState(0)반환
// 배열의 비구조화 할당을 사용하게 되면 가독성이 좋아짐
// 요소에 접근할때 인뎃ㄱ스를 사용하는 것보다 더 직관적
// state의 가장 큰 장점은 state가 변경될때마다 자동으로 state관련 html이 제렌더링 된다
// state 상품명 글제목 가격 이런것처럼 자주 변하는 것 같은데이터를 저장하는 좋은관습
//eslint 는 잘못된 코딩 관습 교정함
// 변수를 만들었는데 안쓰고 있다 지우는게 어떰?
// 이런식의 warning 띄움
// 초보떄는 지키는거보다 코드 짜고 실행이 중요
// /*eslint-disable*/   eslint 잠시 끄기