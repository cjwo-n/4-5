import GoodsCounter from "../src/Components/goods";

function App ( ){
    return(
        <div className="App">
        <h1>test2</h1>
        <GoodsCounter/>
        </div>
    )
}
export default App;