import {createSlice} from '@reduxjs/toolkit'
//import React,{useRef, useState, useMemo} from "react";
// npm i redux react-redux
//리엑트에서 리덕스 사용
//액션생성 함수

// export const addNumber = () =>{
//     return { type:'ADD'}
// }
// export const substractNumber  = () =>{
//     return { type:'substract'}
// }
//초기값
//이 함수를 허출하여 반환된 액션 객체를 redux 스토어에 디스패치
//스토어의 상태를 변경하는 데 사용되는 리듀서 전달

// const initialState = {
//     stock: 10,  //재고
//     goods : 1   //구매개수
// }

// const goodReducer = (state = initialState, action) => {
//     //redux 리듀서는 애플리케이션의 상태를 변경하는 함수로
//     //상태와 액션을 인자로 받아 새로운 상태 반환
//     //action: 디스패친된 액션 객체임
//     //이 객체는 액션 생성함수에 반환된 객체 어떤 동작을 수행해야 하는지 나타냄
//     //type 속성을 포함한다

//     console.log(action)
//     console.log(action.type)
//     console.log(state)
//     switch (action.type){
//         case 'ADD':
//             return{
//                 ...state,
//                 stock: state.stock -1,
//                 goods: state.goods +1
//             }
//         case 'substract':
//             return{
//                 ...state,
//                 stock: state.stock +1,
//                 goods: state.goods -1
//             }
//         default:
//             return state
//     }
// }
//export default goodReducer;

// const initialState = {
//     stock : 10,
//     goods:1
// }
const initialState = {
        stock: 10,  //재고
        goods : 1   //구매개수
    }
export const counterSlice = createSlice({
    name:'counter',
    initialState,   //초기값
    reducers:{      //함수로 바뀐 것이 중요한 특징, 기존처럼 유니크한 이름이 아니어도 됨
        increment:(state)=>{
            state.stock -= 1     //...state 없앰
            state.goods += 1     //...state 없앰

        },
        decrease:(state)=>{
            state.stock += 1     //...state 없앰
            state.goods -= 1     //...state 없앰
        }
    }
})
console.log(counterSlice)
export const {increment,decrease} = counterSlice.actions
//console.log 로 찍어보면 알수 있음
export default counterSlice.reducer 
//reducers처럼 s붙지 않음 console.log 해보면 됨




