export const increment = ( ) =>({type:'increment'})
export const decrease = ( ) =>({type:'decrease'})