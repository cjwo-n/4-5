//import React from "react";

//액션생성 함수
export const sale = ()=>{
    return{type:"sale"};
}
export const soldout = ()=>{
    return{type:'sold_out'};
}
//초기값
const initialState = {
    message:'판매',
};

const stockReducer = (state = initialState, action)=>{
    switch(action.type){
        case 'sale':
            return{
                ...state,
                message:'판매중'
            }
        case 'sold_out':
            return{
                ...state,
                message:'매진'
            }
            default:
                return state
    }
}
export default stockReducer;