import React from "react";
import { Provider } from "react-redux";
import { store } from "./store";
import CounterDisplay from './CounterDisplay'
import CounterButtons from './CounterButtons'

function App(){
    return (
        <Provider store={store}><div>
            <CounterDisplay/>
            <CounterButtons/>
        </div>
        </Provider>
        
    )
}
export default App;