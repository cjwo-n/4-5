import {combineReducers} from 'redux';
import goodsReducer from './230417_03';
import stockReducer from './stock';

const rootReducer = combineReducers({
    goodsReducer,
    stockReducer
});
//두개의 리듀서를 결합해 하나의 루트 리듀서를 만드는 과정 보여줌

export default rootReducer;