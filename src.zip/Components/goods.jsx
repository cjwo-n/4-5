import {useSelector , useDispatch} from 'react-redux'
//import {addNumber , substractNumber} from '../modules/230417_03'
// import { renderHook } from '@testing-library/react'
import { increment, decrease } from '../modules/230417_03'

function GoodsCounter(){
    // const {stock, goods} = useSelector(state =>({
    //     stock: state.stockReducer.stock,
    //     goods: state.goodsReducer.goods
    // }))

    //useSelector : store 상태 조회 hook
    const {stock, goods} = useSelector(state =>{
        console.log('-state start-')
        console.log(state )
        console.log('-state start-')
        return({
            stock: state.stockReducer.stock,
            goods: state.goodsReducer.goods
        })
    })
    console.log(stock, goods)

    //useDispatch : store 이 dispatch를 함수 내부에서 사용가능한 Hook

    const dispatch = useDispatch()

    const onAddNumber = () =>
        //dispatch(addNumber())
        dispatch(increment())

    const onSubstractNumber = () =>
        //dispatch(substractNumber())
        dispatch(decrease())
        
    return(
        <div>
            <h2>딥러닝 개발자 무릎</h2>
            <span><strong>17500</strong>원</span>
            <div>
                <button type='button' onClick={onSubstractNumber}>minus</button>
                <span>{goods}</span>
                <button onClick={onAddNumber}>plus</button>
            </div>
            <div>
                수량 <strong>{goods}</strong>
            </div>
            <div>
                <strong>{goods * 17500}</strong>원
            </div>
            <div>
                재고 <strong>{stock}</strong>
            </div>
        </div>
    )
    
}
export default GoodsCounter;

//리덕스 사용상 잇점
// 예측 가능한 상태 관리
// 디버깅 용이
// 코드의 일관성
// 컴포너트간의 상태공유
// 테스트 용이
// 커뮤니티 지원