import style from './test.module.css'
export default function Test(){
    return(
        <div className={style.test}test2></div>
    )
}