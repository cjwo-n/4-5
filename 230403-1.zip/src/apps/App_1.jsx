import '../css/App.css';

function App(){
    const styleH2 = {border : 'solid 1px black',color:'blue',
    fontSize:'32px' }
return(
    <div>
        <h1>hello world</h1>
        <h2 style={styleH2}>hello world</h2>
        <h2 style={{border : 'solid 1px black',color:'blue',
        fontSize:'32px' }}>hello world</h2>
        <p className='content'>hello world</p>
    </div>
)//app .jsx는 자바스크립트 xml파일의 확장자
//jsx는 리액트 사용되는 템플릿 언어
}
export default App;
//jsx 파일을 자바스크립트 파일오 변환하기 위해 바벨(babel)
//과 같은 도구를 사용
// jsx 파일에는 자스와 html태그 함께
// tsx 타입스크립트 확장자

