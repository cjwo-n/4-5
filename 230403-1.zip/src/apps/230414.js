import React, {Fragment}  from "react";
function App(){
    return(
        <React.Fragment>
        <h1>안녕~</h1>
        <h1>안녕~1</h1>
        </React.Fragment>
    )
}
export default App;
