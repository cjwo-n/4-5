import { setSelectionRange } from '@testing-library/user-event/dist/utils';
import React from 'react';
import { useState } from 'react';
// import '../css/App.css';

function App() {

    let [글제목, 글제목변경] = useState([
      '코트맛집',
      '역전우동',
      '파이썬'
    ]);
    
    let [따봉, 따봉변경]=useState(0);

    let [modal, setModal]=useState(false);// 스위치역활

    [1,2,3].map(function (a) {  //a라고 작명
      console.log(a)
    })//[1,2,3] 배열의 각 요소에 대한 함수 실행
    //map()메소드는 배열의 각 요소에 대한 지정된 함수 실행 새로운 배열 반환
    //기본닷이 false 3개 배열을 갖는다

  return(
  <div className='App'>
      <div className='black-nav'>
        <div>개발 블로그</div>
        <hr/>
      </div>
    {/* 버튼 클릭시 copy에 ...글제목을 복사 함 ...전개연산자로 배열 복사하는데 사용
    그다음 copy의 첫번째 요소를 여자 코트 추천으로 변경 */}
      <button onClick={()=>{
        let copy = [...글제목]; 
        copy[0] = '여자코트 추천';
        글제목변경(copy); //글제목변경 함수를 호출해 글제목 상태를 copy로 업데이트
      }}>수정버튼</button>
  {
    글제목.map(function (a,i){
      return<div className="list" key ={i} >
      <h4>{글제목[i]}<span onClick={()=>따봉변경(따봉 +1)}>😁😁</span>
      {따봉}
      </h4>
      <p>4월 13일</p>
      </div>
      // map 반복문으로 반복생성한 html엔 key={i} 와 같은 속성이 추가되야 된다
      // 반복되는 엘리먼트 를 구분하기 위해 사용
    })
  }
  
  <button onClick={()=>{
    setModal(!modal)
  }}>{글제목[0]}</button>
    {
      modal ==true? <Modal/> : null
    }
  </div>
  )
}
  
function Modal(){
  return(
    <div className="modal">
      <h4>제목</h4>
      <p>날짜</p>
      <p>상세내용</p>
    </div>
  )
}

function Resume(props){
  const[like, setLike] = useState(0)
  const myColor = props.color;
  const styleColor = {color:myColor};
  
  function clickLike(){
    setLike(like +1 )
  }
  // const clickLike = () => {
  //   setLike(like +1)
  // }
  
  return(
  <div style={{border:"solid 1px", width:"500px"}}>
      <h1>{props.name}자기소개서</h1>
      <h1>{props.hello}</h1>
      <h2>취미 : {props.hobby}</h2>
      <h2>음식 : {props.food}</h2>
      <h2>색 : <span style={styleColor}>{myColor}</span></h2>
      <button onClick={clickLike}>like<span>{like}</span></button>
      <div onClick={clickLike}>count{like}</div>
    </div>
  )
}

export default Resume;
//
