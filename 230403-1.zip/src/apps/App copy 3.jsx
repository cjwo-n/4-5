import styled from "styled-components";
import {useEffect} from 'react';
import {useState} from 'react';
//useEffect는 리엑트 훅 중 하나로
//컴포넌트에서 부수 효과(side effect)를 수행할 
// 있도록 해줌
//부수효과란 컴포넌트가 렌더링 될때 외부와 상호
//작용하는 코드를 말함
//api 요청,타이머 설정,dom 조작

function Counter(){
    const[count,setCount]= useState(0)
    const[bool,setBool]= useState(false)
    const handleCountUp= (e) =>{
        setCount(count+1)
}
// useEffect는 함수으이 형태로 사용 첫번째 인자로 콜백함수 받음
// 콜백 함수는 컴포넌트가 렌더링 될 떄 실행
// 두번째 인자로 배열 ㅂ다고 이 배열에 지정된
// 값이 변경될 떄만 콜백 함수가 실행
// 두번째 인자를 생략한다면 모든 값이 변경될때마다 콜백함수 실행
// useEffect 는 컴포넌트가 렌더링 된후 실해오디는 함수로
// 특정 값을 감시하고 있을떄만 해당 값이 변경될때 실행
// 이를 통해 컴포넌트의 상태를 관리할수 있음
// 여기선 count가 컴포넌트의 state로 존재
// 이 state 변할 때만다 뭔가 다은 효과를 주고 싶다
// --useEffect 훅 사용
useEffect(()=>{
    if(bool){
        if(count % 2){
            alert ("홀")
        }else {
            alert("짝")
        }
    }
    setBool(true)
}, [count])

return (
    <>
    <div>{count}</div>
    <button onClick={handleCountUp}>UP1</button>
    </>
)
}
function App(){
    return(
        <div className="App">
            <Counter/>
        </div>
    )
}

export default App;

//초기 랜더링시 bool 상택밧은 false
// handleCountUp 함수가 실행되면count 상태값이 1증가
// useEffect 함수 실행
// bool 값이 false이므로 if 문 안의 코드는 t실행되지 ㅇ낳는다
// setBool(true) 코드가 실행되어 bool 값이 true로 변경
// handleCountUp함수가 다시 실행되면 count값이2가 됨
// useEffect 함수가 다시 실행
// bool 갑싱 true 이므로 if문 안의 코드가 실행됨
// count 값이 2이므로 else문 안의 코드인 짝수 alert창으로 나옴

// 처음렌더링시 bool 값이 false이기 때문ㅇ ㅔ
// useEffect 함수가 실행안됨
// 그러나 첫 클릭 이후부터는 bool 값이 true가됨
// useEffect 함수 실행
// count가 0이므로 count % 2의 값은 0이 됨
// 하지만 bool값이 바뀐후 알림창이 띄워저
// 이전 count 값이 0이 아닌 1이라는 값이 나타남

// useEffect(()=>{
//     state가 변경되어 렌더링 될때 실행하는 부분
//     return()=>{
//         다시 렌더링 하기 이전에 컴포넌트를 지우고 다시 그리고
//         이과정에서 지우기전에 실행되는 부분이다 clean up이라함
//     }
// },[state 값이 들어감 들어지 않으면 최초 1번만실행됨])