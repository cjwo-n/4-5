import styled from "styled-components";
import { useState } from 'react';


const CardDiv = styled.div`
padding:20px;
border:1px solid #c4c4c4;
margin-bottom:20px;
width:${(props)=>(props.className === 'setting'? '200px':'400px')}
`;

const Card = (props) =>{
    return(
        <CardDiv className={props.cardClassName}>
            <h1>{props.title}</h1>
            <h3>{props.value}</h3>
            <hr/>
            <div>{props.children}</div>
        </CardDiv>
    )
}
const ShareCard = () =>{
    return(
        <>
        <p>
            jskdbvskdjvjcskdbvskdjsdkhfjskdvsdjkjnbv
            sdfniksdnfslnv
            snfjskdfnsdlnsdlv
            nsdfljsdnfl
            sdsdsdsd
            d
        </p>
        <div>
            <button>img</button>
            <button>twitter</button>
            <button>facebook</button>
        </div>
        </>
    )
}
const count = (props)=>{
    return(
        <>
        {{props}.value+1}
        </>
        )
    }

const SettingCard = (props) =>{
    return(
        <>
        <br/>
        <button>reset</button>
        <button onClick={props.count}>save</button>
        </>
    )
}


const Test = (props) =>{
    const [tt,setTT] = useState(0);
    const sdd =()=>{
        setTT({tt} + 1)
    }
return(
        <p>
            hello world
            {props.children}
            <button onClick={sdd}>add</button>
            <button>remove</button>
            {/* <TestTwo></TestTwo>
            <TestTwo></TestTwo>
            <TestTwo></TestTwo> */}
        </p>
    )
}

const TestTwo = () =>{
    return(
        <p>
            hello world2
        </p>
    )
}
function App (){
    return(
    <>
    <Card cardClassName='setting' title='챌린지 설정'>
        <SettingCard value={count}></SettingCard>
            <Test>
                <TestTwo ></TestTwo>
            </Test>
        </Card>
            <Card cardClassName='share' title='서비스 공유'>
                <ShareCard></ShareCard>
            </Card>
    </>
    )
}
export default App;
