import React from "react";
import styled,{css} from 'styled-components'
//스타일 적용 npm install-components

    const one = css`
    color:red;
    `;
    const two = css`
    border:1px solid black;
    `;
    const Three = styled.div`
    ${one}
    ${two}`

    const App =() =>{
        return(
            <Three>what the?</Three>
        )
    }

export default App;

