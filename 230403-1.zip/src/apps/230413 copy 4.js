import { setSelectionRange } from '@testing-library/user-event/dist/utils';
import React from 'react';
import { useState } from 'react';
// import '../css/App.css';

function App() {
  const name = '누리호'
  function 함수(){
    return 100
  }
  const 변수 = 10
  const 값 = true
  
  const 값2 = null
  return(
    <div className='App'>
      <h1>안녕{name}1호</h1>
      <p> {100 + 1}</p>
      <p> {'hello' + 'world'}</p>
      <p>{[1,2,3].map(x => x**2)}</p>
      <p>{[함수]}</p>
      <p>{변수}</p>
      <p>{값?'one':'two'}</p>
      <p>{값2??'one'}</p>
    </div>
  )
}

    

export default App;
//?? nullish coalescing 연산자
// 이 연산자는 왼쪽 피연산자가 null 또는 undefined경우 오른쪽 
// 피연산자를 반환
// ㅁ나약 왼쪽 피연산자가 falsy하지만 null
// undefined 아닐경우 왼쪽 피연산자 반환
// 화면에 one이라는 문자열을 표시하는 단락 요소를 추가
// 이 값은 값2변수가 null이므로 one 출력
