//npm install react-bootstrap bootstrap
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button,Navbar,Container,Nav } from 'react-bootstrap';
import '../css/20230413App.css';
//react-bootstrap 라이브러리에서 button navbar container
//nav 컴포넌트 불러오는 코드

//import 'C:\230403-1\node_modules\bootstrap\dist\css';
function App(){
  return(
    <div className="App">
      <br/>
      <Button variant='primary'>primary</Button>
      <Navbar bg="dark" variant="dark">
      <Container>
        <Navbar.Brand href="#home">Navbar</Navbar.Brand>
        <Nav className="#me-auto">
          <Nav.Link href="#home">HOME</Nav.Link>
          <Nav.Link href="#features">FEATURES</Nav.Link>
          <Nav.Link href="#pricing">PRICING</Nav.Link>
        </Nav>
      </Container>
      </Navbar>
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <img src ="https://d2v80xjmx68n4w.cloudfront.net/gigs/fPoZ31584321311.jpg" width="100%"></img>
            <h4>상품명</h4>
            <p>상품정보</p>
          </div>
          <div className="col-md-4">
            <img src ="https://d2v80xjmx68n4w.cloudfront.net/gigs/fPoZ31584321311.jpg" width="100%"></img>
            <h4>상품명</h4>
            <p>상품정보</p>
          </div>
          <div className="col-md-4">
            <img src ="https://d2v80xjmx68n4w.cloudfront.net/gigs/fPoZ31584321311.jpg" width="100%"></img>
            <h4>상품명</h4>
            <p>상품정보</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App;